<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class List_suggest_confirm extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form','url','html'));
        $this->load->library(array('session','form_validation'));
        $this->load->database();
        $this->load->model('Model_list_suggest_confirm');
        
        if($this->session->userdata('login') == TRUE) {
            if($this->session->userdata('login_app') <> 'istok-admin') {
                $this->session->sess_destroy();
                redirect('login');
            }
        } else {
            $this->session->sess_destroy();
            redirect('login');
        }
    }
    
    public function index($id){
        $datasesion = array(
			'user_id' => $this->session->userdata('user_id'),
			'user_level' => $this->session->userdata('user_level'),
			'user_name' => $this->session->userdata('user_name'),
			'user_name_full' => $this->session->userdata('user_name_full')
		);
        
        $data['id'] = $id;
        
        $data_all = $this->Model_list_suggest_confirm->getData($id);
        $data['data_all'] = $data_all;
        
        $data['dd_vendor'] = $this->Model_list_suggest_confirm->getVendor();
        $data['dd_barge'] = $this->Model_list_suggest_confirm->get_list_barge();
        $data['dd_transporter'] = $this->Model_list_suggest_confirm->get_list_transporter();
        
        $this->load->view('header', $datasesion);
        $this->load->view('list_suggest_confirm', $data);
        $this->load->view('footer');
    }
    
    public function simpan($id){
        $this->form_validation->set_rules('quantity', 'quantity', 'trim|required');
        $this->form_validation->set_rules('po_number', 'po_number', 'trim|required');
        $this->form_validation->set_rules('loading_time', 'loading_time', 'trim|required');
        
        if ($this->form_validation->run() == FALSE){
            $this->index($id);
        } else {
            date_default_timezone_set('Asia/Jakarta');
            
            $trans_id = $this->input->post('trans_id');
            $eta_date = new DateTime($this->input->post('posting_date'));
            $quantity = $this->input->post('quantity');
            $vendor_id = $this->input->post('vendor_id');
            $barge_id = $this->input->post('barge_id');
            $transporter_id = $this->input->post('transporter_id');
            $po_number = $this->input->post('po_number');
            $loading_time = $this->input->post('loading_time');
            $storage_id = $this->input->post('storage_id');
            
        }
    }
    
    function forecast_recalculate($id_storage,$trans_id){
        $data_trans_atg = $this->Model_list_suggest_confirm->get_trans_atg($id_storage);
        $atg_vol =0;
        foreach ($data_trans_atg as $row) {
            $atg_vol += $row->volume; 
        }
        
        $data = array(
            'stock_realtime' => $atg_vol
	);		
	$this->Model_list_suggest_confirm->update_mst_parameter($data, $id_storage);
        
        $data_mst_parameter = $this->Model_list_suggest_confirm->get_mst_parameter($id_storage);
        $stock_realtime=0; $stock_min=0; $stock_distribution_parameter=0; $stock_distribution_max_parameter=0;
        $reorder_point=0;
        foreach ($data_mst_parameter as $row){
            $stock_realtime = $row->stock_realtime;
            $stock_min = $row->stock_min;
            $stock_distribution_parameter = $row->average_distribution;
            $stock_distribution_max_parameter = $row->average_distribution_max;
            $reorder_point = $row->reorder_point;
        }
        
        /*if ($max_id != null) {
            $trans_id = $max_id;			
	} else {
            $trans_id = 0;
	}*/
        
        date_default_timezone_set('Asia/Jakarta');
	$tanggal = date('Y-m-d');
	$tanggal_sekarang = date('Y-m-d');
                
        
    }
}
?>