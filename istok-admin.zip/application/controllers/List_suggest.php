<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class List_suggest extends CI_Controller{
    
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->database();
        $this->load->model('Model_list_suggest');
        
        ini_set('max_execution_time', 0); 
        ini_set('memory_limit','2048M');
        
        if ($this->session->userdata('login') == TRUE) {
			if ($this->session->userdata('login_app') <> 'istok-admin') {
				$this->session->sess_destroy();
				redirect('login');
			}
		} else {
			$this->session->sess_destroy();
			redirect('login');
		}
    }
    
    function index(){
        $datasesion = array(
			'user_id' => $this->session->userdata('user_id'),
			'user_level' => $this->session->userdata('user_level'),
			'user_name' => $this->session->userdata('user_name'),
			'user_name_full' => $this->session->userdata('user_name_full')
		);
		
		$data = array(
			'user_id' => $this->session->userdata('user_id'),
			'user_level' => $this->session->userdata('user_level'),
			'user_name' => $this->session->userdata('user_name'),
			'user_name_full' => $this->session->userdata('user_name_full')
		);
        
                $data['list_suggest'] = $this->Model_list_suggest->getListSuggest(1);
                $ddStorage = $this->Model_list_suggest->get_list_storage();
                $data['ddStorage'] = $ddStorage;
                $data['ddYear'] = array(
                    '1' => date("Y", strtotime("-1 year")),
                    '2' => date("Y"),
                    '3' => date("Y", strtotime("+1 year"))
                ) ;
                $data['ddPeriode'] = array(
                    '1' => 'Yearly',
                    '2' => 'Quarterly',
                    '3' => 'Monthly'
                );
                $data['ddSubPeriodeQ'] = array(
                    '1' => 'Q1',
                    '2' => 'Q2',
                    '3' => 'Q3',
                    '4' => 'Q4'
                );
                $data['ddSubPeriodeM'] = array(
                    '1' => 'January',
                    '2' => 'February',
                    '3' => 'Maret',
                    '4' => 'April',
                    '5' => 'May',
                    '6' => 'Juni',
                    '7' => 'July',
                    '8' => 'August',
                    '9' => 'September',
                    '10'=> 'October',
                    '11'=> 'November',
                    '12'=> 'December'
                );
                
                $data['barge'] = $this->Model_list_suggest->getBargeAvailable();
                
                
                $this->load->view('header', $datasesion);
                $this->load->view('list_suggest', $data);
                $this->load->view('footer');
    }
    
    public function getForecastById($id){
        //$id = $this->input->post();
        $result = $this->Model_list_suggest->getSuggestById($id);
        echo json_encode($result);
    }
    
    function confirm(){
        $id = $this->input->post('trans_id');
        $data = array(
            'trans_id' => $this->input->post('trans_id'),
            'storage_id' => $this->input->post('storage_id'),
            'quantity' => $this->input->post('volume'),
            'barge_id' => $this->input->post('po_res_number'),
        );
        $id_barge = $this->input->post('');
        $data_barge = array(
            'durasi_bongkar' => $this->input->post('durasi_bongkar')
        );
        $this->Model_list_suggest->confirm_po($data,$id);
        $this->Model_list_suggest->loading_barge($data_barge,$id_barge);
    }
    
}
?>
