<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800">Home</h1>
	<div class="jumbotron">
		<h1>Welcome Back to IStok <b>Admin</b></h1> 
	</div>	
	<?php echo "LogIn: <b>" .$user_name. " - "  .$user_name_full. "</b>"; ?> | <?php echo "Level: <b>" .$user_level. "</b>"; ?>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
